package org.example;
import lombok.Data;



@Data
public class Paciente {

    private String matricula;
    private String motivo;
    private String nombre;
    private String apPaterno;
    private String apMaterno;
    private String fechaNacimiento;
    private String sexo;
    private String direccion;
    private String telefono;
    private String correo;
    private String curp;
    private String rfc;
    private String estadoCivil;
    private String ocupacion;
    private String religion;
    private String escolaridad;
    private String lugarNacimiento;
    private String tipoSangre;
    private String alergias;
    private String enfermedades;
    private String antecedentes;
    private String motivoConsulta;
    private String padecimientoActual;
    private String exploracionFisica;
    private String diagnostico;
    private String tratamiento;
    private String observaciones;
    private String fecha;
    private String hora;
    private String medico;

    private String password;
    private String tipoUsuario;

    public Paciente(String matricula, String motivo, String nombre, String apPaterno, String apMaterno, String fechaNacimiento, String sexo, String direccion, String telefono, String correo, String curp, String rfc, String estadoCivil, String ocupacion, String religion, String escolaridad, String lugarNacimiento, String tipoSangre, String alergias, String enfermedades, String antecedentes, String motivoConsulta, String padecimientoActual, String exploracionFisica, String diagnostico, String tratamiento, String observaciones, String fecha, String hora, String medico, String password, String tipoUsuario) {

    }
}