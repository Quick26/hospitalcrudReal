package org.example;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PacienteCRUD pacienteCRUD = new PacienteCRUD();
        List<Paciente> pacientes = new ArrayList<>();
        int opcion;
        do {
            System.out.println("VERSION DEL SISTEMA 1.0");
            System.out.println("Bienvenido al sistema de registro de pacientes");
            System.out.println("1. Registrar paciente");
            System.out.println("2. Buscar paciente");
            System.out.println("3. Salir");
            System.out.println("Ingrese una opcion: ");
            opcion = sc.nextInt();
            switch (opcion) {
                case 1:

                    System.out.println("Ingrese la matricula del paciente: ");
                    String matricula = sc.next();
                    System.out.println("Ingrese el motivo de la consulta: ");
                    String motivo = sc.next();
                    System.out.println("Ingrese el nombre del paciente: ");
                    String nombre = sc.next();
                    System.out.println("Ingrese el apellido paterno del paciente: ");
                    String apPaterno = sc.next();
                    System.out.println("Ingrese el apellido materno del paciente: ");
                    String apMaterno = sc.next();
                    System.out.println("Ingrese la fecha de nacimiento del paciente: ");
                    String fechaNacimiento = sc.next();
                    System.out.println("Ingrese el sexo del paciente: ");
                    String sexo = sc.next();
                    System.out.println("Ingrese la direccion del paciente: ");
                    String direccion = sc.next();
                    System.out.println("Ingrese el telefono del paciente: ");
                    String telefono = sc.next();
                    System.out.println("Ingrese el correo del paciente: ");
                    String correo = sc.next();
                    System.out.println("Ingrese la curp del paciente: ");
                    String curp = sc.next();
                    System.out.println("Ingrese el rfc del paciente: ");
                    String rfc = sc.next();
                    System.out.println("Ingrese el estado civil del paciente: ");
                    String estadoCivil = sc.next();
                    System.out.println("Ingrese la ocupacion del paciente: ");
                    String ocupacion = sc.next();
                    System.out.println("Ingrese la religion del paciente: ");
                    String religion = sc.next();
                    System.out.println("Ingrese la escolaridad del paciente: ");
                    String escolaridad = sc.next();
                    System.out.println("Ingrese el lugar de nacimiento del paciente: ");
                    String lugarNacimiento = sc.next();
                    System.out.println("Ingrese el tipo de sangre: ");
                    String tipoSangre = sc.next();
                    System.out.println("Ingrese las alergias del paciente: ");
                    String alergias = sc.next();
                    System.out.println("Ingrese las enfermedades del paciente: ");
                    String enfermedades = sc.next();
                    System.out.println("Ingrese los antecedentes del paciente: ");
                    String antecedentes = sc.next();
                    System.out.println("Ingrese el motivo de consulta del paciente: ");
                    String motivoConsulta = sc.next();
                    System.out.println("Ingrese el padecimiento actual del paciente: ");
                    String padecimientoActual = sc.next();
                    System.out.println("Ingrese la exploracion fisica del paciente: ");
                    String exploracionFisica = sc.next();
                    System.out.println("Ingrese el diagnostico del paciente: ");
                    String diagnostico = sc.next();
                    System.out.println("Ingrese el tratamiento del paciente: ");
                    String tratamiento = sc.next();
                    System.out.println("Ingrese las observaciones del paciente: ");
                    String observaciones = sc.next();
                    System.out.println("Ingrese la fecha: ");
                    String fecha = sc.next();
                    System.out.println("Ingrese la hora: ");
                    String hora = sc.next();
                    System.out.println("Ingrese el medico: ");
                    String medico = sc.next();
                    System.out.println("Ingrese el password: ");
                    String password = sc.next();
                    System.out.println("Ingrese el tipo de usuario: ");
                    String tipoUsuario = sc.next();
                    Paciente paciente = new Paciente(matricula, motivo, nombre, apPaterno, apMaterno, fechaNacimiento, sexo, direccion, telefono, correo, curp, rfc, estadoCivil, ocupacion, religion, escolaridad, lugarNacimiento, tipoSangre, alergias, enfermedades, antecedentes, motivoConsulta, padecimientoActual, exploracionFisica, diagnostico, tratamiento, observaciones, fecha, hora, medico, password, tipoUsuario);
                    pacienteCRUD.insertarPaciente(paciente);
                    break;




                case 2: {
                    System.out.println("Ingrese la matricula del paciente: ");
                    matricula = sc.next();
                    paciente = pacienteCRUD.buscarPaciente(matricula);
                    if (paciente != null) {
                        System.out.println("Matricula: " + paciente.getMatricula());
                        System.out.println("Motivo: " + paciente.getMotivo());
                        System.out.println("Nombre: " + paciente.getNombre());
                        System.out.println("Apellido paterno: " + paciente.getApPaterno());
                        System.out.println("Apellido materno: " + paciente.getApMaterno());
                        System.out.println("Fecha de nacimiento: " + paciente.getFechaNacimiento());
                        System.out.println("Sexo: " + paciente.getSexo());
                        System.out.println("Direccion: " + paciente.getDireccion());
                        System.out.println("Telefono: " + paciente.getTelefono());
                        System.out.println("Correo: " + paciente.getCorreo());
                        System.out.println("Curp: " + paciente.getCurp());
                        System.out.println("Rfc: " + paciente.getRfc());
                        System.out.println("Estado civil: " + paciente.getEstadoCivil());
                        System.out.println("Ocupacion: " + paciente.getOcupacion());
                        System.out.println("Religion: " + paciente.getReligion());
                        System.out.println("Escolaridad: " + paciente.getEscolaridad());
                        System.out.println("Lugar de nacimiento: " + paciente.getLugarNacimiento());
                        System.out.println("Tipo de sangre: " + paciente.getTipoSangre());
                        System.out.println("Alergias: " + paciente.getAlergias());
                        System.out.println("Enfermedades: " + paciente.getEnfermedades());
                        System.out.println("Antecedentes: " + paciente.getAntecedentes());
                        System.out.println("Motivo de consulta: " + paciente.getMotivoConsulta());
                        System.out.println("Padecimiento actual: " + paciente.getPadecimientoActual());
                        System.out.println("Exploracion fisica: " + paciente.getExploracionFisica());
                        System.out.println("Diagnostico: " + paciente.getDiagnostico());
                        System.out.println("Tratamiento: " + paciente.getTratamiento());
                        System.out.println("Observaciones: " + paciente.getObservaciones());
                        System.out.println("Fecha: " + paciente.getFecha());
                    } else {
                        System.out.println("No se encontro el paciente");
                    }
                    break;
                }
                case 3: {
                    System.out.println("Gracias por usar el sistema");
                    break;
                }
                default: {
                    System.out.println("Opcion no valida");
                    break;
                }
            }
        } while (opcion != 3);
    }
}
