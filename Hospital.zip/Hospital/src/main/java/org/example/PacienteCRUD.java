package org.example;

import java.io.*;
import java.util.ArrayList;


public class PacienteCRUD {

    @SuppressWarnings("unchecked")
    public void insertarPaciente(Paciente p) {
            try {
                    FileInputStream leer =
                            new FileInputStream("C:\\Users\\faaxo\\OneDrive\\Escritorio\\pacientes\\Pacientes.txt");
                    ObjectInputStream miStream2 = new ObjectInputStream(leer);
                    Object o = miStream2.readObject();
                    ArrayList<Paciente> otraLista = (ArrayList<Paciente>) o;
                    otraLista.add(p);

                    //escribir de vuelta al archivo
                    FileOutputStream escribir =
                            new FileOutputStream("C:\\Users\\faaxo\\OneDrive\\Escritorio\\pacientes\\Pacientes.txt");
                    ObjectOutputStream miStream = new ObjectOutputStream(escribir);
                    miStream.writeObject(otraLista);
                    miStream.close();
                    miStream2.close();
            } catch (IOException | ClassNotFoundException e) {
                    throw new RuntimeException(e);
            }


    }

    @SuppressWarnings("unchecked")
    public Paciente buscarPaciente(String matricula) {
            Paciente p = null;
            try {
                    FileInputStream leer =
                            new FileInputStream("C:\\Users\\faaxo\\OneDrive\\Escritorio\\pacientes\\Pacientes.txt");
                    ObjectInputStream miStream2 = new ObjectInputStream(leer);
                    Object o = miStream2.readObject();
                    ArrayList<Paciente> otraLista = (ArrayList<Paciente>) o;
                    for (Paciente paciente : otraLista) {
                            if (paciente.getMatricula().equals(matricula)) {
                                    p = paciente;
                                    break;
                            }
                    }
                    miStream2.close();
            } catch (IOException | ClassNotFoundException e) {
                    throw new RuntimeException(e);
            }

        return p;


    }
    }
